CREATE TABLE `users`.`users` (
  `reg_id` INT NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(75) NULL,
  `language` VARCHAR(45) NULL,
  `teamup` VARCHAR(45) NULL,
  PRIMARY KEY (`reg_id`));

INSERT INTO `users`.`users` (`full_name`, `language`, `teamup`) 
VALUES ('John Doe', 'JAVA', 'Yes')
,('Richard Castle', 'JS', 'No')
,('Sheldan Cooper', 'Ruby', 'Yes'),
('Penny', 'Python', 'No');
