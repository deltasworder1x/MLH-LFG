/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mark
 */
public class User 
{ // instance variable fields properties
    
    private int reg_id;
    private String full_name;
    private String language;
    private String teamup;
   

    public User(String full_name, String language, String teamup) {
        this.full_name = full_name;
        this.language = language;
 
    }

    public User(int reg_id, String full_name, String language, String teamup) {
        this.reg_id = reg_id;
        this.full_name = full_name;
        this.language = language;
        this.teamup=teamup;
    }
    
    //getters and setters

    public int getReg_id() {
        return reg_id;
    }

    public void setReg_id(int reg_id) {
        this.reg_id = reg_id;
    }

    public String getFull_name() {
        return full_name;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getTeamup() {
        return teamup;
    }

    public void setTeamup(String teamup) {
        this.teamup = teamup;
    }

   
    /*@Override
    public String toString() {
        return (
                "User ID: "        + getEmployee_id() + "\n"
              + "User Name: "      + getFull_name()   + "\n"
              +"User Gender: "     + getGender()      + "\n"
              +"User Department: " + getDepartment()  + "\n"
              +"User Position: "   + getPosition()    + "\n"
              +"User Salary: "     + getSalary()
                );  
    }*/

    @Override
      public String toString() 
      {return 
              ("Register ID: " + getReg_id() +
              "\n" +
              " Name: " +getFull_name()
              + "\n"+
             " Language: "+ getLanguage()
               + "\n"+
              " Teamup?: "+ getTeamup() );
             }
 

    
    
    
    
    
    
}
