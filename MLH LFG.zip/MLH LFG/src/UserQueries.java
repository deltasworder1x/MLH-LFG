/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mark
 */

//import statements
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;


public class UserQueries {
  
   //declare url username and password as constants
    
   private static final String URL = "jdbc:mysql://localhost:3306/users?zeroDateTimeBehavior=convertToNull";
   private static final String USERNAME = "root";
   private static final String PASSWORD = "";
   
   //instantiate a connection and a prepared statements
      private Connection connection; // manages connection
      //prepared statements
      private PreparedStatement selectAllUsers;
      private PreparedStatement selectUserbyLanguage;
      private PreparedStatement insertNewUser;
      private PreparedStatement updateAnUser;
      private PreparedStatement deleteAnUser;
      
            
   //create a constructor the constructor will have all the prepared statement
      //try catch block
      public UserQueries ()
      {
      
      try {
         connection = 
            DriverManager.getConnection(URL, USERNAME, PASSWORD);

         // create query that selects all entries in the employee table 
         selectAllUsers = connection.prepareStatement(
            "SELECT * FROM users ORDER BY full_name");
         
         // create query that selects entries with id
         // that begin with the specified characters 
         selectUserbyLanguage = connection.prepareStatement(        
            "SELECT * FROM users WHERE language = ? ");     
         
         // create insertNewusers Prepared statement that adds a new employee
         insertNewUser = connection.prepareStatement(         
            "INSERT INTO users (full_name,language,teamup) " +     
            "VALUES (?, ?,?)"); 
         
         
         //update an user
         updateAnUser= connection.prepareStatement(
         "UPDATE users SET full_name=?, language=?, teamup=?"
                 + "  WHERE reg_id=?");
        
         //delete an user
         deleteAnUser= connection.prepareStatement(
         "Delete From employees where reg_id=?");
          
      } 
      catch (SQLException sqlException) {
         sqlException.printStackTrace();
         System.exit(1);
      } 
      
   } 
      
    // select all of the Employees in the database

   public List<User> getAllUsers() {
      // executeQuery returns ResultSet containing matching entries
      try 
        
         (ResultSet resultSet = selectAllUsers.executeQuery()) {
         List<User> results = new ArrayList<User>();
         
         while (
                 resultSet.next()) {
                results.add(new User(
               resultSet.getInt("reg_id"),
               resultSet.getString("full_name"),
               resultSet.getString("language"),
               resultSet.getString("teamup")));
         } 

         return results;
      }
      catch (SQLException sqlException) {
         sqlException.printStackTrace();   
         return null;
      }
      

   }
   
  
   
// select person by id
   public List<User> getUserByLanguage(String language) {
      try {
         selectUserbyLanguage.setString(1, language); 
      }
      catch (SQLException sqlException) {
         sqlException.printStackTrace();
         return null;
      }

      // executeQuery returns ResultSet containing matching entries
      try (ResultSet resultSet = selectUserbyLanguage.executeQuery()) {
         List<User> results = new ArrayList<User>();

         while (resultSet.next()) {
            results.add(new User(
               resultSet.getInt("reg_id"),                  
               resultSet.getString("full_name"),
               resultSet.getString("language"),
               resultSet.getString("teamup")
               ));
         } 

         return results;
      }
      catch (SQLException sqlException) {
         sqlException.printStackTrace();
         return null;
      } 
   }
   
   public int addUser(String fullname,String language, String teamup)
   {
      // insert the new entry; returns # of rows updated
      try {
         // set parameters
         insertNewUser.setString(1, fullname);
         insertNewUser.setString(2, language);
         insertNewUser.setString(3, teamup);
         return insertNewUser.executeUpdate();         
      }
      catch (SQLException sqlException) {
         sqlException.printStackTrace();
         return 0;
      }
   }

   // close the database connection
   public void close() {
      try {
         connection.close();
      } 
      catch (SQLException sqlException) {
         sqlException.printStackTrace();
      } 
   }
    
public int updateUser( String fullname,String language, String teamup, int regid)
{ 
   try 
   {
         // set parameters
         
         updateAnUser.setString(1, fullname);
         updateAnUser.setString(2, language);
         updateAnUser.setString(3, teamup);
         
         updateAnUser.setInt(4, regid);
        
         return updateAnUser.executeUpdate();         
      }
      catch (SQLException sqlException) {
         sqlException.printStackTrace();
         return 0;
      }
   }
//deleteAnEmployee
   public int deleteUser(int regid)
{ 
   try 
   {
         // set parameters
         
         deleteAnUser.setInt(1, regid);
        
         return deleteAnUser.executeUpdate();         
      }
      catch (SQLException sqlException) {
         sqlException.printStackTrace();
         return 0;
      }
   }
}
